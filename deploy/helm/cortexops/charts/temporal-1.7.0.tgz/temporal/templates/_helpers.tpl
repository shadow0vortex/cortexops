{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "temporal.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "temporal.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create the Kubernetes namespace for namespaced resources.
*/}}
{{- define "temporal.kubernetesNamespace" -}}
{{- .Release.Namespace | quote -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "temporal.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create the name of the service account
*/}}
{{- define "temporal.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{ default (include "temporal.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
{{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Return the service account config for a specific component.
*/}}
{{- define "temporal.componentServiceAccountConfig" -}}
{{- $global := index . 0 -}}
{{- $component := index . 1 -}}
{{- $componentValues := dict -}}
{{- if hasKey $global.Values.server $component -}}
  {{- $componentValues = index $global.Values.server $component -}}
{{- else if hasKey $global.Values $component -}}
  {{- $componentValues = index $global.Values $component -}}
{{- end -}}
{{- $componentSA := dict -}}
{{- if and (kindIs "map" $componentValues) (hasKey $componentValues "serviceAccount") -}}
  {{- $componentSA = index $componentValues "serviceAccount" -}}
{{- end -}}
{{- if kindIs "map" $componentSA -}}
{{- $componentSA | toYaml -}}
{{- end -}}
{{- end -}}

{{/*
Return whether a component should render its own service account.
*/}}
{{- define "temporal.componentServiceAccountEnabled" -}}
{{- $global := index . 0 -}}
{{- $component := index . 1 -}}
{{- $componentValues := dict -}}
{{- if hasKey $global.Values.server $component -}}
  {{- $componentValues = index $global.Values.server $component -}}
{{- else if hasKey $global.Values $component -}}
  {{- $componentValues = index $global.Values $component -}}
{{- end -}}
{{- if and (kindIs "map" $componentValues) (hasKey $componentValues "enabled") (not $componentValues.enabled) -}}
false
{{- else -}}
true
{{- end -}}
{{- end -}}

{{/*
Return the service account name for a specific component.
Usage: {{ include "temporal.componentServiceAccountName" (list $ "frontend") }}
Looks up the component-specific serviceAccount first; falls back to the global one.
For server sub-services the path is server.<svc>.serviceAccount;
for top-level components (admintools, web, schema, test) the path is <component>.serviceAccount.
*/}}
{{- define "temporal.componentServiceAccountName" -}}
{{- $global := index . 0 -}}
{{- $component := index . 1 -}}
{{- $componentSA := include "temporal.componentServiceAccountConfig" (list $global $component) | fromYaml -}}
{{- if and (kindIs "map" $componentSA) (hasKey $componentSA "name") -}}
  {{- if eq (default false $componentSA.create) true -}}
    {{ default (include "temporal.componentname" (list $global $component)) $componentSA.name }}
  {{- else -}}
    {{ $componentSA.name }}
  {{- end -}}
{{- else if and (kindIs "map" $componentSA) (eq (default false $componentSA.create) true) -}}
  {{ include "temporal.componentname" (list $global $component) }}
{{- else -}}
  {{ include "temporal.serviceAccountName" $global }}
{{- end -}}
{{- end -}}

{{/*
Define the service account as needed.
When called with just $, uses the global SA (backward compat).
*/}}
{{- define "temporal.serviceAccount" -}}
serviceAccountName: {{ include "temporal.serviceAccountName" . }}
{{- end -}}

{{/*
Define the service account for a specific component.
Usage: {{ include "temporal.componentServiceAccount" (list $ "frontend") }}
*/}}
{{- define "temporal.componentServiceAccount" -}}
serviceAccountName: {{ include "temporal.componentServiceAccountName" . }}
{{- end -}}

{{/*
Create a default fully qualified component name from the full app name and a component name.
We truncate the full name at 63 - 1 (last dash) - len(component name) chars because some Kubernetes name fields are limited to this (by the DNS naming spec)
and we want to make sure that the component is included in the name.
*/}}
{{- define "temporal.componentname" -}}
{{- $global := index . 0 -}}
{{- $component := index . 1 | trimPrefix "-" -}}
{{- printf "%s-%s" (include "temporal.fullname" $global | trunc (sub 62 (len $component) | int) | trimSuffix "-" ) $component | trimSuffix "-" -}}
{{- end -}}

{{/*
Frontend service address as a short in-cluster name (host:port).
*/}}
{{- define "temporal.frontendAddress" -}}
{{- printf "%s-frontend:%d" (include "temporal.fullname" .) (.Values.server.frontend.service.port | int) -}}
{{- end -}}

{{/*
Frontend service address as a fully-qualified cluster DNS name (host.namespace.svc:port).
*/}}
{{- define "temporal.frontendAddress.fqdn" -}}
{{- printf "%s-frontend.%s.svc:%d" (include "temporal.fullname" .) .Release.Namespace (.Values.server.frontend.service.port | int) -}}
{{- end -}}

{{/*
Internal-frontend service address as a short in-cluster name (host:port).
*/}}
{{- define "temporal.internalFrontendAddress" -}}
{{- $internalFrontend := index .Values.server "internal-frontend" -}}
{{- printf "%s-internal-frontend:%d" (include "temporal.fullname" .) ($internalFrontend.service.port | int) -}}
{{- end -}}

{{/*
Internal-frontend service address as a fully-qualified cluster DNS name (host.namespace.svc:port).
*/}}
{{- define "temporal.internalFrontendAddress.fqdn" -}}
{{- $internalFrontend := index .Values.server "internal-frontend" -}}
{{- printf "%s-internal-frontend.%s.svc:%d" (include "temporal.fullname" .) .Release.Namespace ($internalFrontend.service.port | int) -}}
{{- end -}}

{{/*
Define the AppVersion
*/}}
{{- define "temporal.appVersion" -}}
{{- if .Chart.AppVersion -}}
{{ .Chart.AppVersion | replace "+" "_" | quote }}
{{- else -}}
{{ include "temporal.chart" $ }}
{{- end -}}
{{- end -}}

{{/*
Create the annotations for all resources
*/}}
{{- define "temporal.resourceAnnotations" -}}
{{- $global := index . 0 -}}
{{- $scope := index . 1 -}}
{{- $resourceType := index . 2 -}}
{{- $component := "server" -}}
{{- if (or (eq $scope "admintools") (eq $scope "web")) -}}
{{- $component = $scope -}}
{{- end -}}
{{- with $resourceType -}}
{{- $resourceTypeKey := printf "%sAnnotations" . -}}
{{- $componentAnnotations := (index $global.Values $component $resourceTypeKey) -}}
{{- $scopeAnnotations := dict -}}
{{- if hasKey (index $global.Values $component) $scope -}}
{{- $scopeAnnotations = (index $global.Values $component $scope $resourceTypeKey) -}}
{{- end -}}
{{- $resourceAnnotations := merge $scopeAnnotations $componentAnnotations -}}
{{- range $annotation_name, $annotation_value := $resourceAnnotations }}
{{ $annotation_name }}: {{ $annotation_value | quote }}
{{- end -}}
{{- end -}}
{{- range $annotation_name, $annotation_value := $global.Values.additionalAnnotations }}
{{ $annotation_name }}: {{ $annotation_value | quote }}
{{- end -}}
{{- end -}}

{{/*
Create the labels for all resources
*/}}
{{- define "temporal.resourceLabels" -}}
{{- $global := index . 0 -}}
{{- $scope := index . 1 -}}
{{- $resourceType := index . 2 -}}
{{- $component := "server" -}}
{{- if (or (eq $scope "admintools") (eq $scope "web")) -}}
{{- $component = $scope -}}
{{- end -}}
{{- with $scope -}}
app.kubernetes.io/component: {{ . }}
{{ end -}}
app.kubernetes.io/name: {{ include "temporal.name" $global }}
helm.sh/chart: {{ include "temporal.chart" $global }}
app.kubernetes.io/managed-by: {{ index $global "Release" "Service" }}
app.kubernetes.io/instance: {{ index $global "Release" "Name" }}
app.kubernetes.io/version: {{ include "temporal.appVersion" $global }}
app.kubernetes.io/part-of: {{ $global.Chart.Name }}
{{- with $resourceType -}}
{{- $resourceTypeKey := printf "%sLabels" . -}}
{{- $componentLabels := (index $global.Values $component $resourceTypeKey) -}}
{{- $scopeLabels := dict -}}
{{- if hasKey (index $global.Values $component) $scope -}}
{{- $scopeLabels = (index $global.Values $component $scope $resourceTypeKey) -}}
{{- end -}}
{{- $resourceLabels := merge $scopeLabels $componentLabels -}}
{{- range $label_name, $label_value := $resourceLabels }}
{{ $label_name}}: {{ $label_value | quote }}
{{- end -}}
{{- end -}}
{{- range $label_name, $label_value := $global.Values.additionalLabels }}
{{ $label_name }}: {{ $label_value | quote }}
{{- end -}}
{{- end -}}

{{- define "temporal.persistence.filterConfig" -}}
{{- $config := deepCopy . -}}
{{- $defaultStore := $config.defaultStore -}}
{{- $visibilityStore := $config.visibilityStore -}}
{{- $secondaryVisibilityStore := $config.secondaryVisibilityStore | default "" -}}
{{- $patchedDatastores := dict -}}
{{- range $name, $ds := $config.datastores -}}
  {{- $dsCopy := deepCopy $ds -}}
  {{- range $storeType := list "sql" "cassandra" "elasticsearch" -}}
    {{- if hasKey $dsCopy $storeType -}}
      {{- $storeConfig := get $dsCopy $storeType -}}
      {{- if or (hasKey $storeConfig "password") (hasKey $storeConfig "existingSecret") -}}
        {{- if eq $name $defaultStore -}}
          {{- $_ := set $storeConfig "password" "__ENV_TEMPORAL_DEFAULT_STORE_PASSWORD__" -}}
        {{- else if eq $name $visibilityStore -}}
          {{- $_ := set $storeConfig "password" "__ENV_TEMPORAL_VISIBILITY_STORE_PASSWORD__" -}}
        {{- else if eq $name $secondaryVisibilityStore -}}
          {{- $_ := set $storeConfig "password" "__ENV_TEMPORAL_SECONDARY_VISIBILITY_STORE_PASSWORD__" -}}
        {{- else -}}
          {{- $_ := unset $storeConfig "password" -}}
        {{- end -}}
      {{- end -}}
      {{- $_ := set $dsCopy $storeType (omit $storeConfig "existingSecret" "secretKey" "createDatabase" "manageSchema") -}}
    {{- end -}}
  {{- end -}}
  {{- $_ := set $patchedDatastores $name $dsCopy -}}
{{- end -}}
{{- $_ := set $config "datastores" $patchedDatastores -}}
{{- regexReplaceAll "__ENV_(TEMPORAL_.+)__" ($config | toYaml) "{{ env \"$1\" | quote }}" -}}
{{- end -}}

{{- define "temporal.persistence.eachStore" -}}
{{- $stores := dict -}}
{{- $_ := set $stores "default" (include "temporal.persistence.getStoreByType" (list $ "default") | fromYaml) -}}
{{- $_ := set $stores "visibility" (include "temporal.persistence.getStoreByType" (list $ "visibility") | fromYaml) -}}
{{- $secondaryVisibility := include "temporal.persistence.getStoreByType" (list $ "secondaryVisibility") | fromYaml -}}
{{- if $secondaryVisibility -}}
{{- $_ := set $stores "secondaryVisibility" $secondaryVisibility -}}
{{- end -}}
{{- $stores | toYaml -}}
{{- end -}}

{{- define "temporal.persistence.getStore" -}}
{{- $root := index . 0 -}}
{{- $storeName := index . 1 -}}
{{- $datastores := $root.Values.server.config.persistence.datastores }}
{{- $store := dict "name" $storeName -}}
{{- $config := get $datastores $storeName -}}
{{- if hasKey $config "sql" -}}
    {{- $_ := set $store "driver" "sql" -}}
    {{- $storeConfig := get $config "sql" -}}
    {{- if not (hasKey $storeConfig "createDatabase") -}}
        {{- $_ := set $storeConfig "createDatabase" true -}}
    {{- end -}}
    {{- if not (hasKey $storeConfig "manageSchema") -}}
        {{- $_ := set $storeConfig "manageSchema" true -}}
    {{- end -}}
    {{- $_ := set $store "config" $storeConfig -}}
{{- else if hasKey $config "cassandra" -}}
    {{- $_ := set $store "driver" "cassandra" -}}
    {{- $storeConfig := get $config "cassandra" -}}
    {{- if not (hasKey $storeConfig "createDatabase") -}}
        {{- $_ := set $storeConfig "createDatabase" true -}}
    {{- end -}}
    {{- if not (hasKey $storeConfig "manageSchema") -}}
        {{- $_ := set $storeConfig "manageSchema" true -}}
    {{- end -}}
    {{- $_ := set $store "config" $storeConfig -}}
{{- else if hasKey $config "elasticsearch" -}}
    {{- $_ := set $store "driver" "elasticsearch" -}}
    {{- $storeConfig := get $config "elasticsearch" -}}
    {{- if not (hasKey $storeConfig "manageSchema") -}}
        {{- $_ := set $storeConfig "manageSchema" true -}}
    {{- end -}}
    {{- $_ := set $store "config" $storeConfig -}}
{{- else -}}
    {{- fail (printf "No valid driver configured for %s store" $store.name) -}}
{{- end -}}
{{- $store | toYaml -}}
{{- end -}}

{{- define "temporal.persistence.getStoreByType" -}}
{{- $root := index . 0 -}}
{{- $type := index . 1 -}}
{{- $storeName := get $root.Values.server.config.persistence (printf "%sStore" $type) -}}
{{- if $storeName -}}
{{- include "temporal.persistence.getStore" (list $root $storeName) -}}
{{- else -}}
{{- dict | toYaml -}}
{{- end -}}
{{- end -}}

{{- define "temporal.persistence.schema" -}}
{{- $store := . -}}
{{- if eq $store.name "default" -}}
{{- print "temporal" -}}
{{- else -}}
{{- print $store.name -}}
{{- end -}}
{{- end -}}

{{- define "temporal.persistence.secretName" -}}
{{- $root := index . 0 -}}
{{- $store := index . 1 -}}
{{- if $store.config.existingSecret -}}
{{- $store.config.existingSecret -}}
{{- else -}}
{{- include "temporal.componentname" (list $root (printf "%s-store" $store.name)) -}}
{{- end -}}
{{- end -}}

{{- define "temporal.persistence.sql.connectAttributes" -}}
{{- $result := list -}}
{{- range $key, $value := . -}}
  {{- $result = append $result (printf "%s=%v" $key $value) -}}
{{- end -}}
{{- join "&" $result -}}
{{- end -}}

{{/*
Based on Bitnami charts method
Renders a value that contains template.
Usage:
{{ include "common.tplvalues.render" ( dict "value" .Values.path.to.the.Value "context" $) }}
*/}}
{{- define "common.tplvalues.render" -}}
    {{- if typeIs "string" .value }}
        {{- tpl .value .context }}
    {{- else }}
        {{- tpl (.value | toYaml) .context }}
    {{- end }}
{{- end -}}

{{/*
TLS wiring helpers.

These turn the concise `server.tls`/`web.tls` stanzas into the volumes,
volume mounts, server `config.tls` and Web UI environment variables that
Temporal expects. The cert/key/ca paths, volume names and config shape are all
determined by Temporal, so users only supply an existing kubernetes.io/tls
secret (tls.crt, tls.key and ca.crt) and a handful of real choices.

The volume names are fixed constants so that each volume and its mount always
agree; only the mount path is user-configurable.
*/}}

{{/* Server: volumes for the internode/frontend TLS secrets. Renders "[]" when
disabled, so callers should gate on the enabled flags. */}}
{{- define "temporal.server.tls.volumes" -}}
{{- $tls := .Values.server.tls -}}
{{- $volumes := list -}}
{{- if $tls.internode.enabled -}}
{{- $volumes = append $volumes (dict "name" "internode-tls" "secret" (dict "secretName" (required "server.tls.internode.secretName is required when server.tls.internode.enabled is true" $tls.internode.secretName))) -}}
{{- end -}}
{{- if $tls.frontend.enabled -}}
{{- $volumes = append $volumes (dict "name" "frontend-tls" "secret" (dict "secretName" (required "server.tls.frontend.secretName is required when server.tls.frontend.enabled is true" $tls.frontend.secretName))) -}}
{{- end -}}
{{- toYaml $volumes -}}
{{- end -}}

{{/* Server: volume mounts matching temporal.server.tls.volumes. */}}
{{- define "temporal.server.tls.volumeMounts" -}}
{{- $tls := .Values.server.tls -}}
{{- $mounts := list -}}
{{- if $tls.internode.enabled -}}
{{- $mounts = append $mounts (dict "name" "internode-tls" "mountPath" $tls.internode.mountPath "readOnly" true) -}}
{{- end -}}
{{- if $tls.frontend.enabled -}}
{{- $mounts = append $mounts (dict "name" "frontend-tls" "mountPath" $tls.frontend.mountPath "readOnly" true) -}}
{{- end -}}
{{- toYaml $mounts -}}
{{- end -}}

{{/* Server: the config.tls block derived from server.tls. Renders "{}" when
disabled. server.config.tls is deep-merged on top of this by the configmap.

requireClientAuth (mutual TLS) can be turned on either through the concise
server.tls.<section>.requireClientAuth flag or through a server.config.tls
override that is merged on top. We resolve the effective value from both so that
clientCaFiles (which the server needs to verify client certs) is emitted no
matter which one is used; without this, an override would enable the server-side
requirement while leaving the server with no CA to verify clients against. */}}
{{- define "temporal.server.tls.config" -}}
{{- $tls := .Values.server.tls -}}
{{- $rawTls := .Values.server.config.tls | default dict -}}
{{- $config := dict -}}
{{- range $section := list "internode" "frontend" -}}
{{- $s := index $tls $section -}}
{{- if $s.enabled -}}
{{- $requireClientAuth := or $s.requireClientAuth (dig $section "server" "requireClientAuth" false $rawTls) -}}
{{- $server := dict "certFile" (printf "%s/tls.crt" $s.mountPath) "keyFile" (printf "%s/tls.key" $s.mountPath) "requireClientAuth" $requireClientAuth -}}
{{- if $requireClientAuth -}}
{{- $_ := set $server "clientCaFiles" (list (printf "%s/ca.crt" $s.mountPath)) -}}
{{- end -}}
{{- $serverName := required (printf "server.tls.%s.serverName is required when server.tls.%s.enabled is true" $section $section) $s.serverName -}}
{{- $client := dict "serverName" $serverName "rootCaFiles" (list (printf "%s/ca.crt" $s.mountPath)) -}}
{{- $_ := set $config $section (dict "server" $server "client" $client) -}}
{{- end -}}
{{- end -}}
{{- toYaml $config -}}
{{- end -}}

{{/* Web: volume for the TLS secret. Renders "[]" when disabled. */}}
{{- define "temporal.web.tls.volumes" -}}
{{- $tls := .Values.web.tls -}}
{{- $volumes := list -}}
{{- if $tls.enabled -}}
{{- $volumes = append $volumes (dict "name" "web-tls" "secret" (dict "secretName" (required "web.tls.secretName is required when web.tls.enabled is true" $tls.secretName))) -}}
{{- end -}}
{{- toYaml $volumes -}}
{{- end -}}

{{/* Web: volume mount matching temporal.web.tls.volumes. */}}
{{- define "temporal.web.tls.volumeMounts" -}}
{{- $tls := .Values.web.tls -}}
{{- $mounts := list -}}
{{- if $tls.enabled -}}
{{- $mounts = append $mounts (dict "name" "web-tls" "mountPath" $tls.mountPath "readOnly" true) -}}
{{- end -}}
{{- toYaml $mounts -}}
{{- end -}}

{{/* Web: TEMPORAL_TLS_* env for the Web UI -> frontend connection. Renders "[]"
when disabled. See https://docs.temporal.io/references/web-ui-environment-variables */}}
{{- define "temporal.web.tls.env" -}}
{{- $tls := .Values.web.tls -}}
{{- $env := list -}}
{{- if $tls.enabled -}}
{{- $env = append $env (dict "name" "TEMPORAL_TLS_CA" "value" (printf "%s/ca.crt" $tls.mountPath)) -}}
{{- $env = append $env (dict "name" "TEMPORAL_TLS_CERT" "value" (printf "%s/tls.crt" $tls.mountPath)) -}}
{{- $env = append $env (dict "name" "TEMPORAL_TLS_KEY" "value" (printf "%s/tls.key" $tls.mountPath)) -}}
{{- $serverName := $tls.serverName -}}
{{- if $tls.enableHostVerification -}}
{{- $serverName = required "web.tls.serverName is required when web.tls.enableHostVerification is true" $tls.serverName -}}
{{- end -}}
{{- $env = append $env (dict "name" "TEMPORAL_TLS_SERVER_NAME" "value" $serverName) -}}
{{- $env = append $env (dict "name" "TEMPORAL_TLS_ENABLE_HOST_VERIFICATION" "value" (printf "%t" $tls.enableHostVerification)) -}}
{{- end -}}
{{- toYaml $env -}}
{{- end -}}

{{/*
Admin-client TLS: shared wiring for the chart's own `temporal` CLI pods (the
admintools Deployment, the namespace-setup Job and the cluster-health test).
Each connects either to the external frontend or, when enabled, to the
internal-frontend, and those two paths terminate TLS with different certificates:
the frontend uses server.tls.frontend, while the internal-frontend uses the
internode config (server.tls.internode). The helpers take the resolved section
name ("frontend" or "internode") so the matching secret and serverName are
wired. A client certificate is always presented so the pods keep working when
the target requires client auth (mutual TLS), however that requirement was
turned on; a client cert the server does not ask for is simply never sent, so
this is harmless otherwise. The secret is mounted at a fixed path,
/etc/temporal/tls/client. Note the CLI env var names differ from the Web UI's.

temporal.adminClient.tls.section resolves which section applies from whether the
pod targets the internal-frontend; it returns "" when that path has no
chart-managed TLS, and callers gate on the empty string.
*/}}
{{- define "temporal.adminClient.tls.section" -}}
{{- $root := index . 0 -}}
{{- $useInternal := index . 1 -}}
{{- $tls := $root.Values.server.tls -}}
{{- if $useInternal -}}
{{- if $tls.internode.enabled }}internode{{ end -}}
{{- else -}}
{{- if $tls.frontend.enabled }}frontend{{ end -}}
{{- end -}}
{{- end -}}

{{- define "temporal.adminClient.tls.env" -}}
{{- $root := index . 0 -}}
{{- $section := index . 1 -}}
{{- $env := list -}}
{{- if $section -}}
{{- $tls := index $root.Values.server.tls $section -}}
{{- $env = append $env (dict "name" "TEMPORAL_TLS" "value" "true") -}}
{{- $env = append $env (dict "name" "TEMPORAL_TLS_SERVER_CA_CERT_PATH" "value" "/etc/temporal/tls/client/ca.crt") -}}
{{- $env = append $env (dict "name" "TEMPORAL_TLS_SERVER_NAME" "value" (required (printf "server.tls.%s.serverName is required when server.tls.%s.enabled is true" $section $section) $tls.serverName)) -}}
{{- $env = append $env (dict "name" "TEMPORAL_TLS_CLIENT_CERT_PATH" "value" "/etc/temporal/tls/client/tls.crt") -}}
{{- $env = append $env (dict "name" "TEMPORAL_TLS_CLIENT_KEY_PATH" "value" "/etc/temporal/tls/client/tls.key") -}}
{{- end -}}
{{- toYaml $env -}}
{{- end -}}

{{- define "temporal.adminClient.tls.volumes" -}}
{{- $root := index . 0 -}}
{{- $section := index . 1 -}}
{{- $volumes := list -}}
{{- if $section -}}
{{- $tls := index $root.Values.server.tls $section -}}
{{- $volumes = append $volumes (dict "name" "client-tls" "secret" (dict "secretName" (required (printf "server.tls.%s.secretName is required when server.tls.%s.enabled is true" $section $section) $tls.secretName))) -}}
{{- end -}}
{{- toYaml $volumes -}}
{{- end -}}

{{- define "temporal.adminClient.tls.volumeMounts" -}}
{{- $root := index . 0 -}}
{{- $section := index . 1 -}}
{{- $mounts := list -}}
{{- if $section -}}
{{- $mounts = append $mounts (dict "name" "client-tls" "mountPath" "/etc/temporal/tls/client" "readOnly" true) -}}
{{- end -}}
{{- toYaml $mounts -}}
{{- end -}}
